package ar.org.centro8.curso.java.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ar.org.centro8.curso.java.data.services.ClienteDataService;
import ar.org.centro8.curso.java.entities.Cliente;
import ar.org.centro8.curso.java.enums.EstadoCivil;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("servicios/clientes/v1")
public class ClienteController {
    @Autowired
    private ClienteDataService cds;
    
    @GetMapping()
    public String info(){
        return "Servicio clientes Activo";
    }

    /*
    @GetMapping("/sumar")
    public String sumar(@RequestParam("nro1") int nro1,@RequestParam("nro2") int nro2){
        int resultado=nro1+nro2;
        return resultado+"";
    }
    */

    /*
    Método alta:
    url: /alta
    Descripción: ..................
    Parámetros de entrada: 
            Método: POST
            String nombre
            String apellido
            String estadoCivil     SOLTERO, CASADO, VIUDO, DIVORCIADO
            String cuit
            String direccion
            String telefono
            String email
            String comentarios
    Párametro de salida: int id     Id generado por la base. 
    */

    @PostMapping("/alta")
    public String save(
        @RequestParam("nombre")         String nombre,              
        @RequestParam("apellido")       String apellido,
        @RequestParam("estadoCivil")    String estadoCivil,    
        @RequestParam("cuit")           String cuit,
        @RequestParam("direccion")      String direccion,        
        @RequestParam("telefono")       String telefono,
        @RequestParam("email")          String email,                
        @RequestParam("comentarios")    String comentarios
    ){
        try{
            Cliente cliente=new Cliente(
                nombre,                             //nombre, 
                apellido,                           //apellido, 
                EstadoCivil.valueOf(estadoCivil),   //estadoCivil, 
                cuit,                               //cuit, 
                direccion,                          //direccion, 
                telefono,                           //telefono, 
                email,                              //email, 
                comentarios                         //comentarios
            );

            cds.save(cliente);

            return cliente.getId()+"";
        }catch(Exception e){
            return "0";
        }
    }

    @PostMapping(value="/baja")
    public String baja(@RequestParam("id") int id) {
        try{
            cds.remove(id);
            return "true";
        }catch(Exception e){
            return "false";
        }
    }

    @GetMapping(value="/all")
    public List<Cliente>getAll(){
        return cds.getAll();
    }
    

    @GetMapping(value="/byId")
    public Cliente getById(int id){
        return cds.getById(id);
    }

    @GetMapping(value="/byCuit")
    public Cliente getByCuit(String cuit){
        return cds.getByCuit(cuit);
    }
    
}
